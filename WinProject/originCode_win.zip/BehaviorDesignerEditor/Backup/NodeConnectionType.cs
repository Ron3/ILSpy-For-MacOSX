﻿// Decompiled with JetBrains decompiler
// Type: BehaviorDesigner.Editor.NodeConnectionType
// Assembly: BehaviorDesignerEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 99CE4D00-DFA2-42D1-ABFC-D630AB4C1372
// Assembly location: C:\Users\Ron\Desktop\bt\BehaviorDesignerEditor.dll

namespace BehaviorDesigner.Editor
{
  public enum NodeConnectionType
  {
    Incoming,
    Outgoing,
    Fixed,
  }
}
