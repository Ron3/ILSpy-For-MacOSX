﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: Extension]
[assembly: AssemblyVersion("0.0.0.0")]
